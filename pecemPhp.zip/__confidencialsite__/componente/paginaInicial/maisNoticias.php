<?php 

    

?>
<!-- cabeçalho da noticia -->
<div class="container mais-noticias">
    <h1 class="titulo-pagina">OUTRAS NOTÍCIAS</h1>
    <hr />
    <div class="container btn-outras-noticias">
      <a href="#/noticias/caucaia" class="caucaia">
        <img src="https://firebasestorage.googleapis.com/v0/b/jornal-porto-do-pecem.appspot.com/o/imagens%2Fcomplexop.jpg?alt=media&token=d9c6a20e-0929-4372-9b21-b6f2be8d6b2b" />
      </a>

      <a href="#/noticias/caucaia" class="caucaia">
        <img src="https://firebasestorage.googleapis.com/v0/b/jornal-porto-do-pecem.appspot.com/o/imagens%2Fcaucaia.jpg?alt=media&token=d0341f0b-927d-4396-9d65-7b9ced42c569"  />
      </a>

      <a href="#/noticias/goncalo" class="caucaia">
        <img src="https://firebasestorage.googleapis.com/v0/b/jornal-porto-do-pecem.appspot.com/o/imagens%2Fgoncalo.jpg?alt=media&token=1f5763f4-c03c-4137-98c2-5c851209b072"  />
      </a>
      
    </div>
    
   
</div>
        
  


    



