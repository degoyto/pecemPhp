<?php
    // function converteNome($nomeAtual){
    //     if ()
    // }

?>