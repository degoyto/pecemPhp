<?php 

include("api/pegaNoticia.php");
include("api/noticiasAleatorias.php");




?>
<!DOCTYPE html>
<html>
    
    
    
</html>


