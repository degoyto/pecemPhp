<?php
    setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');

?>

<div class="container">
    Pecém,<?php echo ucfirst( utf8_encode( strftime(" %d de %B de %Y") ) ); ?>

    <div class="fundo"></div>

</div>

<style>
    /* .fundo{
        background:
    } */
</style>
