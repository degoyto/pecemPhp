<?php ?>

<div class="container caixa">
    <p><?php echo $exibe['tipo']; ?></p>
    <h1><?php echo $exibe['title']; ?></h1>
    <p><?php echo $exibe['resumo']; ?> </p>
    <img src="<?php echo $exibe['fotoUrl']; ?>"/>
    <p><?php echo $exibe['conteudo']; ?> </p>
</div>