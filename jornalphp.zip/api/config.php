<?php 
    $descricao = 'informatica, hospedagem, criação de sites, cloud';
    $teste = "hello";
    header('Content-Type: text/html; charset=utf-8');


?>