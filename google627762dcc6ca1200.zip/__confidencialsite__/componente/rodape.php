<?php

?>
<div class="container-flex">
    <!-- <div class="div-anuncio-rodape">
        <a href="#">
            <img src="https://firebasestorage.googleapis.com/v0/b/jornal-porto-do-pecem.appspot.com/o/anuncio.jpg?alt=media&token=df4d99dd-84b5-4a9e-bda9-e15c12842135"/>
        </a>
    </div> -->
    <div class="rodape">
        <div class="container itens">
            <ul>
                <li><a href="/noticias/<?php echo $listaPalavras[(6)]?>" >destaques portuários</a></li>
                    <li><a href="/noticias/<?php echo $listaPalavras[(11)]?>" >Nacionais</a></li>
                            
                    <li><a href="/noticias/<?php echo $listaPalavras[(12)]?>"  >Internacionais</a></li>
                    
                    <li><a href="/noticias/<?php echo $listaPalavras[(1)]?>"  >Artigos e Opinião</a></li>
                    
                    <li><a href="/noticias/<?php echo $listaPalavras[(13)]?>"  > turismo</a></li>

                    <li><a href="/noticias/<?php echo $listaPalavras[(4)]?>"  >Comércio exterior</a></li>
                    <li><a href="/noticias/<?php echo $listaPalavras[(9)]?>" >logística e transporte</a></li>
                    <li><a href="/noticias/<?php echo $listaPalavras[(7)]?>"  >entrevistas</a></li> 
                    <li><a href="/noticias/<?php echo $listaPalavras[(12)]?>"  >Portos do Brasil</a></li>
                    <li><a href="/noticias/<?php echo $listaPalavras[(8)]?>"  >Eventos</a></li>
            </ul>
        </div>
        <div class="container menu2">
            <ul class="menu-rodape" >

                <!-- 
                <li><a class="primeiro-link" href="#">INFORMAÇÕES ÚTEIS</a></li>
                <li><a href="#">EMPREGOS NO PECÉM</a></li>    

                <li><a href="https://jornalportodopecem.com.br/#/quemsomos">QUEM SOMOS</a></li>
                <li><a href="https://jornalportodopecem.com.br/#/expediente">EXPEDIENTE</a></li>
                <li><a href="#">CONTATO</a></li>
                -->
            </ul>
			
			<p class="copyright">Copyright Jornal do Porto do Pecém 2019. Todos os direitos reservados.</p>
        
        </div>
        
    </div>
    
</div>

